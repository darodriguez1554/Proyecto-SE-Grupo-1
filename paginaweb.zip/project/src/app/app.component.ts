import { Component, OnInit } from '@angular/core'
import { Http, Response, Headers, RequestOptions } from '@angular/http'
import { Observable } from 'rxjs/Rx'

import 'rxjs/add/operator/map'
import 'rxjs/add/operator/catch'


declare var google: any
declare var $: any

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent implements OnInit {
  title = 'app works!'
  date1: Date
  date2: Date


  humedad = []
  presion = []
  temperatura = []
  velocidad = []

  constructor(private http: Http) {
    this.loadScript('https://www.gstatic.com/charts/loader.js', data => {
    })
  }

  ngOnInit() {
    $('#rango').daterangepicker({

    }, (start, end, label) => {
      this.date1 = new Date(start)
      this.date2 = new Date(end)
      const fec = {
        d2: this.date1.getTime(),
        d1: this.date2.getTime()
      }


      const headers = new Headers({ 'Content-Type': 'application/json' }) // ... Set content type to JSON
      const options = new RequestOptions({ headers: headers }) // Create a request option
      
      this.http.post('http://localhost:3000/datos', fec, options)
        .map((res: Response) => res.json())
        .subscribe(
        ok => {


          this.humedad = []
          this.presion = []
          this.temperatura = []
          this.velocidad = []

          this.humedad.push(['fecha', 'humedad'])
          this.temperatura.push(['fecha', 'Temperatura'])
          this.presion.push(['fecha', 'presion atmosferica'])

          this.velocidad.push(['velocidad', 'Velocidad del viento'])
          ok.forEach(element => {

            this.humedad.push([element['fecha'] + ' ' + element['hora'], element['humedad']])
            this.temperatura.push([element['fecha'] + ' ' + element['hora'], element['temperatura']])
            this.presion.push([element['fecha'] + ' ' + element['hora'], element['presion']])
            this.velocidad.push([element['fecha'] + ' ' + element['hora'], element['vel']])
          })
          this.actualizarGrafica()
        },
        err => {
          console.log(err)
        }
        )
    })

  }


  actualizarGrafica(){
    google.charts.load('current', { 'packages': ['corechart'] })


    const drawChart = () => {
        const data = google.visualization.arrayToDataTable(
          this.humedad
        )

        const options = {
          title: 'Humedad relativa',
          hAxis: {title: 'Fecha',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
        }

        const chart = new google.visualization.AreaChart(document.getElementById('chart_div'))
        chart.draw(data, options)







        const data2 = google.visualization.arrayToDataTable(
          this.temperatura
        )

        const options2 = {
          title: 'Temperatura relativa',
          hAxis: {title: 'Fecha',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
        }

        const chart2 = new google.visualization.AreaChart(document.getElementById('chart_div2'))
        chart2.draw(data2, options2)




        const data3 = google.visualization.arrayToDataTable(
          this.presion
        )

        const options3 = {
          title: 'Presion',
          hAxis: {title: 'Fecha',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
        }

        const chart3 = new google.visualization.AreaChart(document.getElementById('chart_div3'))
        chart3.draw(data3, options3)





        const data4 = google.visualization.arrayToDataTable(
          this.velocidad
        )

        const options4 = {
          title: 'Velocidad',
          hAxis: {title: 'Fecha',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
        }

        const chart4 = new google.visualization.AreaChart(document.getElementById('chart_div4'))
        chart3.draw(data4, options4)


      }

      google.charts.setOnLoadCallback(drawChart)

  }

  loadScript(filename, callback) {
    const fileref = document.createElement('script')
    fileref.setAttribute('type', 'text/javascript')
    fileref.onload = callback
    fileref.setAttribute('src', filename)
    // tslint:disable-next-line:triple-equals
    if (typeof fileref != 'undefined') {
      document.getElementsByTagName('head')[0].appendChild(fileref)
    }
  }
}
